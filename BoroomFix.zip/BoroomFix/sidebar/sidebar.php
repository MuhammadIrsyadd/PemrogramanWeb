<!-- SIDEBAR -->

<div class="sidebar">
    <a href="landing_page.php"><img class="" src="./assets/logo-side.png" alt="Logo Boroom"></a>
    <ul class="wrapside">
        <a class="wrapper" href="./index.php" >
            <img class="sidelog" src="./assets/shape.png" alt="beranda">
            <li>BERANDA</li>
        </a>
        <a class="wrapper" href="./u_peminjaman.php">
            <img class="sidelog" src="./assets/rent.png" alt="peminjaman">
            <li>PEMINJAMAN</li>
        </a>
        <a class="wrapper" href="./u_riwayat.php">
            <img class="sidelog" src="./assets/riwayat.png" alt="riwayat">
            <li>RIWAYAT</li>
        </a>
        <a class="wrapper "href="./u_notifikasi.php">
            <img class="sidelog" src="./assets/notif.png" alt="notifikasi">
            <li>NOTIFIKASI</li>
        </a>
        <a class="wrapper" href="u_profil.php">
            <img class="sidelog" src="./assets/profil.png" alt="profil">
            <li class="logout">PROFIL</li>
        </a>
    </ul>
</div>