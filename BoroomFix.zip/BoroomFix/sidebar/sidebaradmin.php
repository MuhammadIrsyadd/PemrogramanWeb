<!-- SIDEBAR ADMIN -->

<div class="sidebar">
    <a href="a_signin.php"><img class="" src="../assets/logo-side.png" alt="Logo Boroom"></a>
    <ul class="wrapside">
        <a class="wrapper" href="../admins/indexadmin.php" >
            <img class="sidelog" src="../assets/shape.png" alt="beranda">
            <li>BERANDA</li>
        </a>
        <a class="wrapper" href="../admins/a_tambah.php">
            <img class="sidelog" src="../assets/tambah.png" alt="tambah ruangan">
            <li>TAMBAH RUANGAN</li>
        </a>
        <a class="wrapper" href="../admins/a_up.php">
            <img class="sidelog" src="../assets/update.png" alt="update ruangan">
            <li>UPDATE RUANGAN</li>
        </a>
        <a class="wrapper" href="../admins/a_hapus.php">
            <img class="sidelog" src="../assets/hapus.png" alt="hapus ruangan">
            <li>HAPUS RUANGAN</li>
        </a>
        <a class="wrapper "href="../admins/a_ajuan.php">
            <img class="sidelog" src="../assets/notif.png" alt="status ajuan">
            <li>STATUS AJUAN</li>
        </a>
        <a class="wrapper" href="../admins/a_profil.php">
            <img class="sidelog" src="../assets/profil.png" alt="profil">
            <li class="logout">PROFIL</li>
        </a>
    </ul>
</div>